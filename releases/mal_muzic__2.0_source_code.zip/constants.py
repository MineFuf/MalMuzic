DEFAULT_DIR_FILE_TEST = 'python3.dll'
DEFAULT_LISTS = ['watching', 'completed', 'onhold', 'dropped', 'ptw']
PAGE_LIMIT = 0